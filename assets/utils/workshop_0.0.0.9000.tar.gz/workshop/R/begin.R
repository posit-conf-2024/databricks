#' @export
#' @import cli
begin <- function() {
  cli_inform("hello")
}
